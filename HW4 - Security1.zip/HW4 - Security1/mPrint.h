#ifndef __MPRINT_H
#define __MPRINT_H

#define mPrint(s) (printf("%s:%d:%s\n",__FILE__,__LINE__,s))

#endif
